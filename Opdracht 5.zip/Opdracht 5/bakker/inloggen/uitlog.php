<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
<link rel="icon" href="../images/Screen Shot 2019-05-23 at 13.42.57.png">
</head>

<body>
	
	<?php
	
		session_start();
	
	$_SESSION['Gebruikersnaam'] == "";
	unset($_SESSION['Gebruikersnaam']);
	
	session_unset();
	
	session_destroy();
	
	header("Location:https://82957.ict-lab.nl/test/bakker/index.html");
	
	echo "<a href='inlog.php'>Terug naar de inlog pagina</a>"
	
	?>
</body>
</html>