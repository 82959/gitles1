<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>bestellingen uitlezen</title>
<link href="../css/style.css" type="text/css" rel="stylesheet">
	<link rel="icon" href="../images/Screen Shot 2019-05-23 at 13.42.57.png">
</head>

<?php

	require "config.php";

if ($_SESSION['Level'] >= 0){
		
	$query = "select * from Bestelling";
		
	$resultaat = mysqli_query($mysqli,$query);
	?> 

<link href="../css/style.css" type="text/css" rel="stylesheet">

<div class="knoppen">
		  <div class= "uit"><a href="uitlog.php">uitloggen</a></div>
	</div>
	
<!--Hier onder de content van de pagina-->
	<div class="siteinfo">
        <div class="vaklinks">
			<?php
	if (mysqli_num_rows($resultaat) == 0)
			{
		echo "Er zijn geen resultaten gevonden";
	}
	else{
		echo "<table border=1";
		echo "<tr>";
		echo "<th>thema</th>";
		echo "<th>topping</th>";
		echo "<th>buitenkant</th>";
		echo "<th>vulling</th>";
		echo "<th>mail</th>";
		echo "<th>voornaam</th>";
		echo "<th>achternaam</th>";
		echo "</tr>";
		
		while ($rij = mysqli_fetch_array($resultaat)){
			echo "<tr>";
			echo "<td>" . $rij['thema'] . "</td>";
			echo "<td>" . $rij['topping'] . "</td>";
			echo "<td>" . $rij['buitenkant'] . "</td>";
			echo "<td>" . $rij['vulling'] . "</td>";
			echo "<td>" . $rij['mail'] . "</td>";
			echo "<td>" . $rij['voornaam'] . "</td>";
			echo "<td>" . $rij['achternaam'] . "</td>";
			echo "<td> <a href='klaarverwijder.php?id=".$rij['ID_bestelling']."'>klaar</a> </td>";
		}
		
		echo "</table>";
	}
	}
	else{
		echo "Je hebt hier niet genoeg rechten om dit te zien";
	}
?>
    </div>