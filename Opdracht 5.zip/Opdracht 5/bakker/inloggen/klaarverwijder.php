<?php

	require "config.php";
	
session_start();
	
	if ($_SESSION['Level'] == 5){

	$id = $_GET['id'];
	
	$query = "select * from Bestelling where ID_bestelling= $id";
		
	$resultaat = mysqli_query($mysqli,$query);

	if (mysqli_num_rows($resultaat) == 0) {
		echo "Er zijn geen resultaten gevonden";
	}
	else{
		echo "<table border=1";
		echo "<tr>weet je zeker dat je klaar bent met deze bestelling?</tr>";
		echo "<tr>";
		echo "<th>thema</th>";
		echo "<th>topping</th>";
		echo "<th>buitenkant</th>";
		echo "<th>vulling</th>";
		echo "<th>mail</th>";
		echo "<th>voornaam</th>";
		echo "<th>achternaam</th>";
		echo "</tr>";
		
		while ($rij = mysqli_fetch_array($resultaat)){
			echo "<tr>";
			echo "<td>" . $rij['thema'] . "</td>";
			echo "<td>" . $rij['topping'] . "</td>";
			echo "<td>" . $rij['buitenkant'] . "</td>";
			echo "<td>" . $rij['vulling'] . "</td>";
			echo "<td>" . $rij['mail'] . "</td>";
			echo "<td>" . $rij['voornaam'] . "</td>";
			echo "<td>" . $rij['achternaam'] . "</td>";
			echo "</tr>";
		}
		
		echo "</table>";
	}
	echo "<br>";
	echo "<a href='klaar_verwerk.php?id=$id'>JA</a>";
	echo "<br>";
	echo "<a href='uitlezen.php'>NEE</a>";

}
	else{
		echo "Je hebt hier niet genoeg rechten om dit te zien";
	}
?>