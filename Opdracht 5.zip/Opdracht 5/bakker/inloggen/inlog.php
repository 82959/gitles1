<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Inloggen</title>
<link rel="icon" href="../images/Screen Shot 2019-05-23 at 13.42.57.png">
<link href="../css/style.css" type="text/css" rel="stylesheet">
</head>

<body>
	
	<?php
	
		if (isset($_POST['Login']))
		{
			require 'config.php';
			
			$Gebruikersnaam = $_POST['Gebruikersnaam'];
			$Wachtwoord = $_POST['Wachtwoord'];
			
			$query = "SELECT * FROM `user` WHERE Gebruikersnaam= '$Gebruikersnaam' AND Wachtwoord= '$Wachtwoord'";
			$resultaat = mysqli_query($mysqli, $query);
				
			if (mysqli_num_rows($resultaat) > 0){
				
				$user = mysqli_fetch_array($resultaat);
				session_start();
				$_SESSION['Gebruikersnaam'] = $user['Gebruikersnaam'];
				$_SESSION['Level'] = $user['Level'];
				
				header("Location:https://82957.ict-lab.nl/test/bakker/inloggen/uitlezen.php");
				
			}
			else{
				echo "Je gegevens zijn fout!";
				
			}
		}
		else{
	
	?>
		<div class="knoppen">
		<div class= "knoplinks">
		</div>
      <div class= "knop"><a href="../index.html">Home</a></div>
	  <div class= "knop"><a href="../taarten.html">Taarten</a></div>
	  <div class= "knop"><a href="../data/bestellingtoevoegen.php">Custom</a></div>
			<div class= "knoprechts">
	</div>
	</div>
	
<!--Hier onder de content van de pagina-->
	<div class="siteinfo">
        <div class="vaklinks">
			<p>
				<div class="backgroundinloggen">
					<p>
	<h2 style="margin-left: 10px; text-align: center;">Inloggen</h2>
	<form method="post" action="">
			<input type="text" placeholder="Enter Username" name="Gebruikersnaam" required><br>
			<br>
			<input type="password" placeholder="Enter Password" name="Wachtwoord" required><br>
			<br>
			<input class="loginbutton" type="submit" name="Login" value="submit">
		</p>
	</form><br>
</div>
			</p>
        </div>
    </div>
	
	<?php
		}
	?>
</body>
</html>