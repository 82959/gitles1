<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>taart besteld</title>
<link rel="icon" href="../images/Screen Shot 2019-05-23 at 13.42.57.png">
<link href="../css/style.css" type="text/css" rel="stylesheet">
</head>

<?php

require "config.php";

session_start();
	
	if ($_SESSION['Level'] == 5){

$userid = $_GET['id'];

$query = "DELETE FROM `Bestelling` WHERE ID_bestelling = $userid";

if(mysqli_query($mysqli,$query))
{
	echo "Je bent klaar met de taart";
}
else{
	echo "Er ging iets mis";
}
echo "<br>";
echo "<a href='uitlezen.php'>Terug naar het overzicht</a>";
header("Location:https://82957.ict-lab.nl/test/bakker/inloggen/uitlezen.php");
		}
	else{
		echo "Je hebt hier niet genoeg rechten om dit te zien";
	}
?>