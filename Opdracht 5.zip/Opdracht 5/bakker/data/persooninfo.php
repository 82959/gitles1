<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>persoon's info</title>
	<link href="../css/style.css" type="text/css" rel="stylesheet">
	<link rel="icon" href="../images/Screen Shot 2019-05-23 at 13.42.57.png">
</head>

<body>
	<?php
	require "config.php";
		
		$thema = $_POST['thema'];
		$topping = $_POST['topping'];
		$buitenkant = $_POST['buitenkant'];
		$vulling = $_POST['vulling'];
		
		$query = "INSERT INTO `Bestelling` (`ID_bestelling`, `thema`, `topping`, `buitenkant`, `vulling`) VALUES (NULL, '$thema', '$topping', '$buitenkant', '$vulling');";
			?>
	<div class="test">
	<form method="post" action="bestelling_verwerken.php">
			mail<br>
			<input type="text" placeholder="Enter mail" name="mail" required><br>
			voornaam<br>
			<input type="text" placeholder="Enter voornaam" name="voornaam" required><br>
			achternaam<br>
			<input type="text" placeholder="Enter achternaam" name="achternaam" required><br>
			<input class="loginbutton" type="submit" name="Login" value="submit">
		</p>
	</form>
		</div>
</body>
</html>