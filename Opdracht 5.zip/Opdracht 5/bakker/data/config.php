<?php
		// database logingegevens
		$db_hostname = 'localhost:3306'; // of'127.0.0.1
		$db_username = 'bakker';
		$db_password = 'ndcY22%4';
		$db_datebase = 'Bakker';
	
		//maak de database-verbinding
		$mysqli = mysqli_connect($db_hostname, $db_username, $db_password, $db_datebase);
			
		//als de verbinding niet gemaakt kan worden: geef een foutmelding
		if (!$mysqli) {
			echo "FOUT: geen connectie naar database. <br>";
			echo "Errno" . mysqli_connect_error() . "<br>";
			echo "error" . mysqli_connect_error() . "<br>";
			exit;
		}
?>