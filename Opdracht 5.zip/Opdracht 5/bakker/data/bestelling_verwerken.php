<link rel="icon" href="../images/Screen Shot 2019-05-23 at 13.42.57.png">
<link href="../css/style.css" type="text/css" rel="stylesheet">
<?php
	
	require "config.php";
		
		$thema = $_POST['thema'];
		$topping = $_POST['topping'];
		$buitenkant = $_POST['buitenkant'];
		$vulling = $_POST['vulling'];
		$mail = $_POST['mail'];
		$voornaam = $_POST['voornaam'];
		$achternaam = $_POST['achternaam'];
	

		$query = "INSERT INTO `Bestelling` (`ID_bestelling`, `thema`, `topping`, `buitenkant`, `vulling`, `mail`, `voornaam`, `achternaam`) VALUES (NULL, '$thema', '$topping', '$buitenkant', '$vulling', '$mail', '$voornaam', '$achternaam');";
	
		if (mysqli_query($mysqli, $query)){
			?>
<div class="knoppen">
		<div class= "knoplinks">

		</div>
            <div class= "knop"><a href="../index.html">Home</a></div>
	  <div class= "knop"><a href="../taarten.html">Taarten</a></div>
	  <div class= "knop"><a href="../data/bestellingtoevoegen.php">Custom</a></div>
			<div class= "knoprechts">
	</div>
	</div>
			<div class="siteinfo" style="margin: 10px; height: 50vh">
        <div class="vaklinks">
			<p>
				Je bestelling is toegevoegt.<br>
				Er word contact met uw opgenomen als u bestelling klaar zijn.
			</p>
        </div>
    </div>
<?php
		}
		else {
			echo "fout";
		}
?>