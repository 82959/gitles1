<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Bestelling toevoegen</title>
	<link href="../css/style.css" type="text/css" rel="stylesheet">
	<link rel="icon" href="../images/Screen Shot 2019-05-23 at 13.42.57.png">
</head>

<body>
	<?php
	require "config.php";
	?>
	<div class="knoppen">
		<div class= "knoplinks">
		  <div class= "knop"><a href="../inloggen/inlog.php">inloggen</a></div>
		</div>
            <div class= "knop"><a href="../index.html">Home</a></div>
	  <div class= "knop"><a href="../taarten.html">Taarten</a></div>
	  <div class= "knop"><a href="../data/bestellingtoevoegen.php">Custom</a></div>
			<div class= "knoprechts">
	</div>
	</div>
	
<!--Hier onder de content van de pagina-->
	<div class="siteinfo">
        <div class="vaklinks">
			<div class="test">
	<form action="bestelling_verwerken.php" method="post">
		<p>thema</p>
		<select name="thema" class="select-css">
  			<option value="bruiloft">bruiloft</option>
  			<option value="verjaardag">verjaardag</option>
			<option value="Pokemon">Pokemon </option>
			<option value="Verjaardag">Verjaardag </option>
			<option value="Cars">Cars </option>
			<option value="Meme’s">Meme’s </option>
			<option value="Auto’s">Auto’s </option>
			<option value="Marvel">Marvel </option>
			<option value="Krozantjes">Krozantjes </option>
			<option value="Games">Games </option>
			<option value="Dora">Dora </option>
			<option value="Sinterklaas">Sinterklaas </option>
			<option value="Lava">Lava </option>
			<option value="Minecraft">Minecraft </option>
			<option value="Kerst">Kerst </option>
			<option value="Roblox">Roblox </option>
			<option value="Frozen">Frozen </option>
			<option value="Moffel en Piertje">Moffel en Piertje </option>
			<option value="Sesamstraat">Sesamstraat </option>
			<option value="Suiker">Suiker </option>
			<option value="Gezonken">Gezonken </option>
			<option value="Hamkaas">Hamkaas </option>
			<option value="Water">Water </option>
			<option value="Lucht">Lucht </option>
			<option value="Arrde">Arrde </option>
			<option value="Vuur">Vuur </option>
			<option value="Kaas">Kaas </option>
			<option value="Nederland">Nederland </option>
			<option value="Anime">Anime </option>
		</select>
		<p>topping</p>
		<select name="topping" class="select-css">
  			<option value="aardbei">aardbei</option>
  			<option value="chocolade">chocolade</option>
			<option value="zwitsere room">zwitsere room</option>
  			<option value="mascarpone room">mascarpone room</option>
			<option value="botercréme">botercréme</option>
  			<option value="lemon">lemon</option>
			<option value="ganache">ganache</option>
  			<option value="banketbakkersroom">banketbakkersroom</option>
			<option value="amandelspijs">amandelspijs</option>
  			<option value="marsepijn">marsepijn</option>
		</select>
		<p>buitenkant</p>
		<select name="buitenkant" class="select-css">
  			<option value="aardbei">aardbei</option>
  			<option value="chocolade">chocolade</option>
			<option value="zwitsere room">zwitsere room</option>
  			<option value="mascarpone room">mascarpone room</option>
			<option value="botercréme">botercréme</option>
  			<option value="lemon">lemon</option>
			<option value="ganache">ganache</option>
  			<option value="banketbakkersroom">banketbakkersroom</option>
			<option value="amandelspijs">amandelspijs</option>
  			<option value="marsepijn">marsepijn</option>
		</select>
		<p>vulling</p>
		<select name="vulling" class="select-css">
  			<option value="aardbei">aardbei</option>
  			<option value="chocolade">chocolade</option>
			<option value="zwitsere room">zwitsere room</option>
  			<option value="mascarpone room">mascarpone room</option>
			<option value="botercréme">botercréme</option>
  			<option value="lemon">lemon</option>
			<option value="ganache">ganache</option>
  			<option value="banketbakkersroom">banketbakkersroom</option>
			<option value="amandelspijs">amandelspijs</option>
  			<option value="marsepijn">marsepijn</option>
		</select>
		<br/><br/>
		<h1>persooninfo</h1>
			mail<br>
			<input type="text" placeholder="Enter mail" name="mail" required><br>
			voornaam<br>
			<input type="text" placeholder="Enter voornaam" name="voornaam" required><br>
			achternaam<br>
			<input type="text" placeholder="Enter achternaam" name="achternaam" required><br>
		<input type="submit" class="loginbutton" value="verzenden">
	</form>
		</div>
        </div>
    </div>
</body>
</html>